from django.apps import AppConfig


class OlineeditorappConfig(AppConfig):
    name = 'OnlineEditorApp'
